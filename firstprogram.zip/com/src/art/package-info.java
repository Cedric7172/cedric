package art;
import java.util.Scanner;
class FirstProgram
{
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter a number: ");
		int num1 = scanner.nextInt();
		if(num1%2==0)
		{
			System.out.println("entered number is even ");
		}
		else
		{
			System.out.println("entered number is odd");
	}
}}
